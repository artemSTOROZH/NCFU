# Программирование на языке высокого уровня (Python).
# Задание № 4.3.3. Вариант 8
#
# Выполнил: Стороженко А.В.
# Группа: ПИН-б-о-21-1
# E-mail: artem_storozhenko_2016@mail.ru

import json


class Queue:
    def __init__(self, items=[], front=None, rear=None, name=None):
        """
        Инициализация атрибутов класса Очередь. Параметр имя является необязательным,

        Первый и последний элементы очереди задаются, если в ней есть хотя бы один элемент.
        """
        self._items = items  # Элементы  очереди
        self.name = name     # Название объекта (необязательно)
        if len(items) > 0:
          self.front = items[0]
          self.rear = items[-1]

    def get_items(self):

        """Получение списка элементов очереди"""

        return self._items

    def enqueue(self, item):
        """Добавить элемент в конец очереди"""
        self._items.append(item)
        self.rear = item
        if len(self._items) == 1:   # Если в очереди всего один элемент, то front = rear
            self.front = item
    
    def dequeue(self):
        """Вернуть и убрать из очереди первый элемент.
           Если элементов в очереди нет, вызывается IndexError"""
        if not self.isEmpty():
          if len(self._items) >= 2:
            self.front = self._items[1]
          else:
            self.front = -1     # Если был удален последний элемент, значение front устанавливается по умолчанию
          return self._items.pop(0)
        else:
          raise IndexError
    
    def __str__(self):

        """Строковое представление класса. Возвращается список элементов"""

        return f"{self._items}"
    
    def isEmpty(self):

        """Проверка на пустоту очереди"""

        if len(self._items) < 1:
          return True
        else:
          return False
    
    def clear(self):

        """Очистка очереди"""

        self.front = None
        self.rear = None
        self._items = []
    
    def contains(self, item):

        """Проверка на вхождение элемента в очередь"""

        if item in self._items:
          return True
        else:
          return False
    
    def from_string(self, str_value):

        """Создание элемента из строки"""

        return Queue(str_value.split(","))

    def save(self, filename):

        """Сохранение объекта в JSON - файл"""

        queue_json = {'_items' : self._items}
        if not self.isEmpty():
            queue_json.update({'front' : self.front, 'rear' : self.rear})   # Если очередь не пустая,
                                                                            # то в JSON - файл записывабются значения front и rear
        with open(f"{filename}.json", "w") as file:
            json.dump(queue_json, file, indent=2)

    def load(self, filename):

        """Загрузка объекта из JSON - файла. Возвращает объект, находящийся в JSON - файле"""

        with open(f"{filename}.json") as file:
            obj_dict = json.load(file)
        queue = Queue(obj_dict["_items"])
        self.front = obj_dict["front"]
        self.rear = obj_dict["rear"]
        self._items = obj_dict["_items"]
        return queue

    def __add__(self, other):

        """Перегрузка оператора сложения для очереди.
           Сложение происходит с первым элементом очереди, который после этого из нее убирается"""

        if ((isinstance(other, int) and isinstance(self.front, int)) or             #   Проверка соответствия типов
                (isinstance(other, float) and isinstance(self.front, float))):
            result = self.front + other
            self.dequeue()
            return result
        else:
            raise ValueError

    def __sub__(self, other):

        """Перегрузка оператора вычитания. Принцип работы аналогичен перегрузке метода сложения"""

        if ((isinstance(other, int) and isinstance(self.front, int)) or             #   Проверка соответствия типов
                (isinstance(other, float) and isinstance(self.front, float))):
            result = self.front - other
            self.dequeue()
            return result
        else:
            raise ValueError

    def __mul__(self, other):

        """Перегрузка оператора умножения. Принцип работы аналогичен перегрузке метода сложения"""

        if isinstance(other, (int, float)) and isinstance(self.front, (int, float)):    #   Проверка соответствия типов
            result = self.front * other
            self.dequeue()
            return result
        else:
            raise ValueError

    def __truediv__(self, other):
        """Перегрузка оператора деления. Принцип работы аналогичен перегрузке метода сложения"""
        if isinstance(other, (int, float)) and isinstance(self.front, (int, float)):    #   Проверка соответствия типов
            result = self.front / other
            self.dequeue()
            return result
        else:
            raise ValueError

    def __floordiv__(self, other):

        """Перегрузка оператора деления нацело. Принцип работы аналогичен перегрузке метода сложения"""

        if isinstance(other, int) and isinstance(self.front, int):
            result = self.front // other
            self.dequeue()
            return result
        else:
            raise ValueError