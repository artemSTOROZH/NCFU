import time
from random import *


class Vehicle:
    _environment = None
    _mechanical = None
    _malfunctions = []

    def __init__(self, max_speed, mechanical):
        self.max_speed = max_speed
        self.__mechanical = mechanical

    def move(self, environment):
        if self._environment != environment:
            raise ValueError("Wrong environment")
        else:
            print("The vehicle is moving")

    def _is_mechanical(self):
        if self._mechanical == "mechanical":
            return True
        else:
            return False

    def get_env(self):
        return self._environment

    def _refuel(self):
        if self._is_mechanical():
            print("Refueling the vehicle...")
            time.sleep(5)
            print("The vehicle is fueled\n")
        else:
            raise Exception("Non-mechanical vehicle")

    def _change_oil(self):
        if self._is_mechanical():
            print("Changing oil...")
            time.sleep(1.5)
            print("Oil changed\n")
        else:
            raise Exception("Non-mechanical vehicle")


class WheeledVehicle(Vehicle):
    def __init__(self, max_speed, mechanical, number_of_wheels):
        super().__init__(max_speed, mechanical)
        self._environment = "ground"
        self._number_of_wheels = number_of_wheels
        self._mechanical = mechanical
        self.__possible_malfunctions = {"wheel_damage": {"probability": 0.005, "action": self._change_wheels},
                                        "refuel": {"probability": 0.002, "action": self._refuel},
                                        "oil_aging": {"probability": 0.003, "action": self._change_oil},
                                        "brakes_malfunction": {"probabiity": 0.0007, "action": self._repair_brakes}
                                        }


    def _change_wheels(self):
        print("Changing the wheels...")
        time.sleep(0.25)
        for i in range(1, self._number_of_wheels + 1):
            time.sleep(1)
            print(f"Wheel {i} changed")
        time.sleep(0.2)
        print("Wheels changed\n")

    def _repair_brakes(self):
        print("Repairing the brakes...")
        time.sleep(6)
        time.sleep(0.2)
        print("Brakes are repaired\n")

    def move(self, environment, travel_length):
        time.sleep(0.5)
        print("The wheeled vehicle is moving")
        distance_traveled = 0
        while distance_traveled < travel_length:
            distance_traveled += 1
            time.sleep(1 / self.max_speed)
            print("\r", end="")
            print(f"{distance_traveled} / {travel_length} km", end='')
            if self._is_mechanical():
                if random() < self.__possible_malfunctions["oil_aging"]["probability"]:
                    self._malfunctions.append("oil_aging")
                if random() < self.__possible_malfunctions["refuel"]["probability"]:
                    self._malfunctions.append("refuel")
            if random() < self.__possible_malfunctions["brakes_malfunction"]["probability"]:
                self._malfunctions.append("brakes_malfunction")
            self.__do_service()
        print()
        print("The wheeled vehicle has arrived to the final destination")


class WaterVehicle(Vehicle):
    def __init__(self, mechanical, max_speed):
        super().__init__(max_speed, mechanical)
        self._environment = "water"
        self._mechanical = mechanical
        self.__posible_malfunctions = {"oil_aging": {"probability": 0.002, "action": self._change_oil},
                                       "refuel": {"probability": 0.005, "action": self._refuel},
                                       "leak": {"probability": 0.0001, "action": self._close_leak}
                                      }

    def _close_leak(self):
        print("Closing the leak...")
        time.sleep(3)
        print("The leak is closed")
        time.sleep(0.5)
        print("Removing the water...")
        time.sleep(5)
        print("Water is removed")

    def __do_service(self):
        if len(self._malfunctions) > 0:
            print("\nDiagnosing the water vehicle...")
            if "refuel" in self._malfunctions:
                print("Refuel required")
            if "oil_aging" in self._malfunctions:
                print("Change of oil required")
            if "leak" in self._malfunctions:
                print("Leak detected")
            for malfunction in self._malfunctions:
                self.__posible_malfunctions[malfunction]["action"]()
            self._malfunctions.clear()
            print("\nWater vehicle service is finished")

    def move(self, environment, travel_length):
        time.sleep(0.5)
        print("The water vehicle is moving")
        distance_traveled = 0
        while distance_traveled < travel_length:
            distance_traveled += 1
            time.sleep(1 / self.max_speed)
            print("\r", end="")
            print(f"{distance_traveled} / {travel_length} km", end='')
            if self._is_mechanical():
                if random() < self.__possible_malfunctions["oil_aging"]["probability"]:
                    self._malfunctions.append("oil_aging")
                if random() < self.__possible_malfunctions["refuel"]["probability"]:
                    self._malfunctions.append("refuel")
            if random() < self.__possible_malfunctions["leak"]["probability"]:
                self._malfunctions.append("leak")
            self.__do_service()
        print()
        print("The water vehicle has arrived to the final destination")


class Car(WheeledVehicle):
    def __init__(self, max_speed):
        super().__init__(max_speed, number_of_wheels=4, mechanical=True)
        self._mechanical = "mechanical"
        self.__possible_malfunctions = {"wheel_damage": {"probability": 0.001, "action": self._change_wheels},
                                        "oil_aging": {"probability": 0.002, "action": self._change_oil},
                                        "refuel": {"probability": 0.005, "action": self._refuel},
                                        "brake_malfunction": {"probability": 0.0001, "action": self._repair_brakes},
                                        "light_malfunction": {"probability": 0.008, "action": self._repair_lights}
                                        }

    def _repair_lights(self):
        print("Repairing headlights...")
        time.sleep(3)
        print("Headlights functioning\n")
        time.sleep(0.5)
        print("Repairing back lights...")
        time.sleep(3)
        print("Back lights functioning\n")

    def __do_service(self):
        if len(self._malfunctions) > 0:
            print("\nDiagnosing the car...")
            if "wheel_damage" in self._malfunctions:
                print("Wheels are damaged")
            if "refuel" in self._malfunctions:
                print("Refuel required")
            if "oil_aging" in self._malfunctions:
                print("Change of oil required")
            if "brake_malfunction" in self._malfunctions:
                print("Brakes malfunction detected")
            if "light_malfunction" in self._malfunctions:
                print("Lights malfunctioning detected")
            for malfunction in self._malfunctions:
                self.__possible_malfunctions[malfunction]["action"]()
            self._malfunctions.clear()
            print("\nCar service is finished")

    def move(self, environment, travel_length):
        time.sleep(0.5)
        print("The car is moving")
        distance_traveled = 0
        while distance_traveled < travel_length:
            distance_traveled += 1
            time.sleep(1 / self.max_speed)
            print("\r", end="")
            print(f"{distance_traveled} / {travel_length} km", end='')
            if random() < self.__possible_malfunctions["wheel_damage"]["probability"]:
                self._malfunctions.append("wheel_damage")
            if random() < self.__possible_malfunctions["refuel"]["probability"]:
                self._malfunctions.append("refuel")
            if random() < self.__possible_malfunctions["brake_malfunction"]["probability"]:
                self._malfunctions.append("brake_malfunction")
            if random() < self.__possible_malfunctions["light_malfunction"]["probability"]:
                self._malfunctions.append("light_malfunction")
            self.__do_service()
        print()
        print("The car has arrived to the final destination")


