USE master
EXEC sp_change_users_login 'Auto_Fix' ,'User_2'