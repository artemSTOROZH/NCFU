DENY SELECT ON OBJECT::Employee
TO User_2
DENY SELECT ON OBJECT::DismissalDocument
TO User_2
DENY SELECT ON OBJECT::DismissalArticle
TO User_2