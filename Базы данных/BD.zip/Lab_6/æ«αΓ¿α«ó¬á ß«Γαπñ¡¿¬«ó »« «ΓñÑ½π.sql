USE Dismissal
SELECT EmpID, LastName, FirstName, JobTitle, EnterDate, DepartmentName FROM Employee
ORDER BY DepartmentName