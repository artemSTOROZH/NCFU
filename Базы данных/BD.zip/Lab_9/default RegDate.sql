USE Dismissal
ALTER TABLE DismissalDocument 
ADD DEFAULT SYSDATETIME() FOR RegDate