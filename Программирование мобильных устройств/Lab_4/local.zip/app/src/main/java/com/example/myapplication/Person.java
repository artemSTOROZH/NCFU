package com.example.myapplication;

public class Person {
    public int _id;
    public String name;
    public int Age;
    public Person(int id, String n, int a){
        _id = id;
        name = n;
        Age = a;
    }
}
