package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    SQLHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = new SQLHelper(this);
        ContentValues cv = new ContentValues();
        cv.put("name", "Artem");
        cv.put("Age", "20");
        LinearLayout ll = (LinearLayout)findViewById(R.id.ll);
        LinearLayout row;
        ArrayList<Person> persons = getList();
        Person person_1 = new Person(1, "Артем", 20);
        persons.add(person_1);
        Person person_2 = new Person(2, "Игорь", 26);
        persons.add(person_2);
        Person person_3 = new Person(3, "Светлана", 19);
        persons.add(person_3);
        Person person_4 = new Person(4, "Александр", 22);
        persons.add(person_4);
        Person person_5 = new Person(5, "Владимир", 27);
        persons.add(person_5);
        for (Person p: persons){
            row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);

            TextView id = new TextView(this);
            id.setText(Integer.toString(p._id));
            id.setWidth(120);


            TextView name = new TextView(this);
            name.setText(p.name);
            name.setWidth(200);

            TextView Age = new TextView(this);
            Age.setText(Integer.toString(p.Age));
            Age.setWidth(120);

            row.addView(id);
            row.addView(name);
            row.addView(Age);

            ll.addView(row);
        }
    }
    public ArrayList<Person> getList(){
        ArrayList<Person> persons = new ArrayList<>();
        Cursor cursor = db.getFullTable();
        if (cursor != null){
            while (cursor.moveToNext()) {
                persons.add(new Person(cursor.getInt(0), cursor.getString(1), cursor.getInt(2)));
            }
        }
        return persons;
    }
}