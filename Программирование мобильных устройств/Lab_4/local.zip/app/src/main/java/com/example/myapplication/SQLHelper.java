package com.example.myapplication;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SQLHelper extends SQLiteOpenHelper {

    public SQLHelper(Context context) {
        super(context, "TrainBase", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + "table1 ( _id integer primary key autoincrement, name text not null, Age integer not null);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS table1");
        onCreate(db);
    }

    public Cursor getFullTable(){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.query("table1", new String[] {" _id", "name", "Age"}, null, null, null, null, null);
    }
}
